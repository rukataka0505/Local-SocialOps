import { createClient } from '@/lib/supabase/server';
import { notFound } from 'next/navigation';

import { Button } from '@/components/ui/button';
import Image from 'next/image';

import { ClientInfoDialog } from '@/components/clients/client-info-dialog';
import { getTeamSettings } from '@/actions/teams';

// レイアウトはサーバーコンポーネントとしてデータ取得を行う
export default async function ClientLayout({
    children,
    params,
}: {
    children: React.ReactNode;
    params: Promise<{ id: string }>;
}) {
    const { id } = await params;
    const supabase = await createClient();

    const { data: client } = await (supabase as any)
        .from('clients')
        .select('*')
        .eq('id', id)
        .single();

    if (!client) {
        notFound();
    }

    const settings = await getTeamSettings();

    return (
        <div className="flex h-full flex-col bg-background">
            {/* 共通ヘッダー */}
            <div className="flex items-center justify-between border-b px-6 py-4">
                <div className="flex items-center gap-4">
                    <h1 className="text-2xl font-bold tracking-tight">{client.name}</h1>
                    <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium text-muted-foreground">
                        投稿管理
                    </span>
                    <ClientInfoDialog client={client} settings={settings} />
                </div>

            </div>



            {/* ページコンテンツ */}
            <div className="flex-1 overflow-auto bg-muted/10 p-6">
                {children}
            </div>
        </div>
    );
}
